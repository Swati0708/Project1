let date = document.getElementById("date");
let day = document.getElementById("day");

let days = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

let dateObj = new Date();
let dateValue = dateObj.toLocaleDateString();
let dayValue = days[dateObj.getDay()];

date.innerHTML = dateValue;
day.innerHTML = dayValue;

let cityValue = document.getElementById("cityValue");
let temp = document.getElementById("temp");
let tempData = document.getElementById("temp-data");
let initialValue = document.getElementById("initialValue");
initialValue.innerHTML = "Please Enter City...";

let wether = async () => {

  // let url = `https://api.openweathermap.org/data/2.5/weather?q=surat&lat=35&lon=139&appid=7bc2cda0fa50d0b20ffe2ef0d2426e4a`;

  try {
    let apiKey = `7bc2cda0fa50d0b20ffe2ef0d2426e4a`;
    let city = document.getElementById("city").value;
    let url = `https://api.openweathermap.org/data/2.5/weather?q=${city.toLowerCase()}&lat=35&lon=139&appid=${apiKey}`;

    let res = await fetch(url);
    let data = await res.json();

    // console.log(data);

    if (res.status == 404) {
      tempData.innerHTML = "City Not Found...";
      setTimeout(() => {
        location.reload();
      }, 1500);
    } else {
      initialValue.hidden = true;
      cityValue.innerText = data.name;
      let celsius=(data.main.temp - 273.15).toFixed(1);  //kelvin
      temp.innerHTML = `${celsius} °C`;
      city = document.getElementById("city").value = "";
    }
  } catch (err) {
    console.log(err.message);
  }

};
